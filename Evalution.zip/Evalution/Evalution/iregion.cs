﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Evalution2
{
    public interface Iregion
    {
        int Id { get; set; }
        string Name { get; set; }
        int Edges { get; set; }

        int GetArea();
        void MoveRegion(int x, int y);
        void Resize(int x, int y);
        void Intersect();
    }
    class Circle : Iregion
    {
        public string Name { get; set; }
        public int Id { get; set; }
        public int Edges { get; set; }

        private int r;

        int x = 4;
        int y = 5;

        public Circle(int r, string name, int id, int edges)
        {
            this.r = r;
            Name = name;
            Id = id;
            Edges = edges;
        }

        public int GetArea()
        {
            double area = 3.14 * Math.Pow(r, 2);
            return (int)area;
        }
        public void MoveRegion(int x, int y)
        {
            x += x;
            y += y;
            Console.WriteLine($"New region axis is at:{x} , {y}");
        }
        public void Resize(int x, int y)
        {
            r = r + x;
        }
        public void Intersect()
        {

        }
    }
    class Rectangle : Iregion
    {
        public string Name { get; set; }
        public int Id { get; set; }
        public int Edges { get; set; }

        int length;
        int breadth;
        public Rectangle(int a, int b, string name, int id, int edges)
        {
            length = a;
            breadth = b;
            Name = name;
            Id = id;
            Edges = edges;
        }
        int x = 4;
        int y = 5;
        public int GetArea()
        {
            double area = length * breadth;
            return (int)area;
        }
        public void MoveRegion(int x, int y)
        {
            x += y;
            y += x;

            Console.WriteLine($"New region axis is at:{x} , {y}");
        }
        public void Resize(int x, int y)
        {
            length += y;
            breadth -= x;
        }
        public void Intersect()
        {

        }
    }
    class Triangle : Iregion
    {
        public string Name { get; set; }
        public int Id { get; set; }
        public int Edges { get; set; }

        int length;
        int height;
        public Triangle(int a, int b, string name, int id, int edges)
        {
            length = a;
            height = b;
            Name = name;
            Id = id;
            Edges = edges;
        }

        public int GetArea()
        {
            double area = (1 / 2) * height * length;
            return (int)area;
        }
        public void MoveRegion(int x, int y)
        {
            length += y;
            height += x;
        }
        public void Resize(int x, int y)
        {
            length += y;
            height -= x;
        }
        public void Intersect()
        {

        }
    }
}
