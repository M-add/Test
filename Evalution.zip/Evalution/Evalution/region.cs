﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Evalution2;

namespace Evalution1
{
    public static class RegionManager
    {
        public static List<Iregion> regions = new List<Iregion>();

        public static void AddRegion()
        {
            Console.WriteLine("What region you want to add");
            Console.WriteLine("circle \nTriangle \nRectangle");          

            string s = Console.ReadLine();

            if(s.ToLower().Equals("circle"))
            {
                Console.WriteLine("Enter Radius");
                int r = int.Parse(Console.ReadLine());

                Console.WriteLine("Enter Id:");
                int id = int.Parse(Console.ReadLine());

                Console.WriteLine("Enter Name:");
                string name = Console.ReadLine();

                Circle obj = new Circle(r , name , id , 0);

                regions.Add(obj);
            }
            else if((s.ToLower().Equals("rectangle")))
            {
                Console.WriteLine("Enter Length & Breadth");
                int l = int.Parse(Console.ReadLine());
                int b = int.Parse(Console.ReadLine());

                Console.WriteLine("Enter Id:");
                int id = int.Parse(Console.ReadLine());

                Console.WriteLine("Enter Name:");
                string name = Console.ReadLine();

                Rectangle obj = new Rectangle(l, b , name , id , 4);

                regions.Add(obj);
            }
            else
            {
                Console.WriteLine("Enter Length & Height");

                int l = int.Parse(Console.ReadLine());
                int h = int.Parse(Console.ReadLine());

                Console.WriteLine("Enter Id:");
                int id = int.Parse(Console.ReadLine());

                Console.WriteLine("Enter Name:");
                string name = Console.ReadLine();

                Triangle obj = new Triangle(l, h , name , id , 3);
                regions.Add(obj);
            }

        }
        public static void RemoveRegion()
        {
            Console.WriteLine("All the Id's:");
            foreach(var item in regions)
            {
                Console.Write(item.Id + "\n");
            }
            Console.WriteLine("Enter the region Id you wanna remove:");
            int id = int.Parse(Console.ReadLine());
            
            foreach(var item in RegionManager.regions.ToList())
            {
                if(item.Id == id)
                {
                    regions.Remove(item);
                }
            }
        }
        public static void GetAllRegions()
        {
            if(RegionManager.regions.Count == 0)
            {
                Console.WriteLine("Empty:");
                return;
            }
            foreach (var i in RegionManager.regions)
            {
                Console.Write(i.Id +" " + i.Name + "\n");
            }
        }
        public static void GetRegion()
        {
            Console.WriteLine("Enter the region Id you want:");
            int id = int.Parse(Console.ReadLine());

            foreach (var i in RegionManager.regions)
            {
                if(i.Id == id)
                {
                    Console.WriteLine(i.Name);
                    break;
                }
            }
        }
        public static void RegionOperations()
        {
            Console.WriteLine("All the Id's:");
            foreach (var item in regions)
            {
                Console.Write(item.Id + "\n");
            }
            Console.WriteLine("Enter the region Id you want to perform operations on:");
            int id = int.Parse(Console.ReadLine());

            foreach (var item in RegionManager.regions)
            {
                if (item.Id == id)
                {
                    Console.WriteLine("Enter the operation You want to perform");
                    
                    while(true)
                    {
                        Console.WriteLine("1 . GetArea \n2 . Move \n3 . Resize \n4 . Intersect");
                        int n = int.Parse(Console.ReadLine());
                        switch (n)
                        {
                            case 1:
                                Console.WriteLine(value: $"Area of {item.Name} is:{item.GetArea()}");
                                break;
                            case 2:
                                int x = int.Parse(Console.ReadLine());
                                int y = int.Parse(Console.ReadLine());
                                item.MoveRegion(x,y);
                                break;
                            case 3:
                                Console.WriteLine("Enter resize values:");
                                if(item.Edges == 0)
                                {
                                    Console.WriteLine("Its a circle:");
                                    int a = int.Parse(Console.ReadLine());
                                    item.Resize(a, a);
                                }
                                else
                                {
                                    int a = int.Parse(Console.ReadLine());
                                    int b = int.Parse(Console.ReadLine());
                                    item.Resize(a, b);
                                }
                                
                                break;
                            case 4:
                                item.Intersect();
                                break;

                        }
                        Console.WriteLine("Press Q to quit and Y to continue");

                        string s = Console.ReadLine();

                        if (s[0] == 'q')
                        {
                            break;
                        }
                        else
                        {
                            continue;
                        }
                    }
                    break;
                }
            }
        }
    }
}
